import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FeedbackServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String subject = req.getParameter("subject");
		String message = req.getParameter("message");
	
		Model m =new Model();
		
		m.setName(name);
		m.setEmail(email);
		m.setSubject(subject);
		m.setMessage(message);
		
		int data = UserDao.savedata(m);
		
		if(data>0)
		{
			out.print("success");
		}
		else
		{
			out.print("fail");
		}
		
	}
}
