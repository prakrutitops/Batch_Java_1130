package com.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Student;

public class CRUD {
	public Connection getConnect() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud23","root","");
	return conn;
	
	}
	
	public Student getSingle(Student s) throws ClassNotFoundException, SQLException
	{
		Student student = new Student();
		Connection conn = new CRUD().getConnect();
		PreparedStatement ps= conn.prepareStatement("select * from Student where name=? and password=?");
		ps.setString(1, s.getName());
		ps.setString(2, s.getPassword());
		ResultSet rs = ps.executeQuery();
		if (rs.next())
		{
			student.setId(rs.getInt(1));
			student.setName(rs.getString(2));
			student.setPassword(rs.getString(3));
		}
		conn.close();
		return student;
	}

}
