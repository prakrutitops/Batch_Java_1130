package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connect.CRUD;
import com.model.Student;

@WebServlet("/insertc")
public class insertc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String name = request.getParameter("name");
			String password = request.getParameter("pass");
	Student s = new Student();
	s.setName(name);
	s.setPassword(password);
	Student sess =null;
	try {
		sess = new CRUD().getSingle(s);
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if (sess != null)
	{
	Cookie ck = new Cookie("user", sess.getName());
	Cookie ck1 = new Cookie("pass", sess.getPassword());
	ck.setMaxAge(20);
	ck1.setMaxAge(20);
	response.addCookie(ck1);
	response.addCookie(ck);
	response.sendRedirect("showcookie.jsp");
	}
	
	else
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("Invalid user ...please try again");
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.include(request, response);
		
	}
	
	
	}


}
