package com.model;

public class Model 
{
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void initializedata()
	{
		System.out.println("Initialize");
	}
	public void destroydata()
	{
		System.out.println("Destroy");
	}
	
}
